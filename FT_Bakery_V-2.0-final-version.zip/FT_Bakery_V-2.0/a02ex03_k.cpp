#include <string>
#include "a02ex03_b.hpp"
#include "a02ex03_j.hpp"
#include "a02ex03_k.hpp"

using namespace std;

Milk::Milk(string type,float liters ,double valor)  : Liquid(liters,valor)
{
    this->type = type;
};

string Milk::getDescricao()
{
   return ("Milk " + type + " - " + to_string(liters)  + " L.");
};

/* fim de arquivo */
