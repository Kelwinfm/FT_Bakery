/* Unicamp - Universidade Estadual de Campinas
   FT - Faculdade de Tecnologia
   Limeira - SP
   Felipe Tosta Santos
   Abri/2017
*/

#include <string>
#include "a02ex03_b.hpp"

using namespace std;

Food::Food(double valor)
   {
   this->valor = valor;
   };
   
double Food::getValor()
   { 
   return (valor); 
   };
   
/* fim de arquivo */
