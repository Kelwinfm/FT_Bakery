#include "a02ex03_j.hpp"

using namespace std;

Liquid::Liquid(float liters, double valor): Food(valor)
{
    this->liters = liters;
}

float Liquid::getLiters()
{
   return (liters);
};

/* fim de arquivo */
