#ifndef A02EX03_J_H
#define A02EX03_J_H

#include <string>
#include "a02ex03_b.hpp"
using namespace std;

class Liquid : public Food
{
    protected:
        float liters;

    public:
    Liquid(float,double);
    virtual float getLiters();
    virtual string getDescricao() = 0;
};

#endif // A02EX03_J_H

/* fim de arquivo */
