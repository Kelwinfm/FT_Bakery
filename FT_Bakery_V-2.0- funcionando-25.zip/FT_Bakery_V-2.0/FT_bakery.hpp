#ifndef FT_BAKERY_H
#define FT_BAKERY_H

class FT_bakery
{
    public:
        FT_bakery();
        virtual ~FT_bakery();

    protected:

    private:
};

#endif // FT_BAKERY_H
